from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import exc
from flask_wtf import Form
from wtforms import TextField, IntegerField, TextAreaField, SubmitField, RadioField,SelectField
from wtforms import validators, ValidationError

#dimiourgia instance tou flask kai arxikopoiisi me tin sindesi tis sqlite3
userFlask = Flask(__name__)
userFlask.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///hospital_db.sqlite3'
userFlask.config['SECRET_KEY'] = "random string"
#orizei tin vasi os sqlalchemy
db = SQLAlchemy(userFlask)
#i customer wtf form kai i sindesi tis me tin html
class CustomerForm(Form):
    name = TextField("Name:")
    lastname = TextField("Lastname:")
    dateofbirth = TextField("Birth date:")
    ssn = TextField("SSN:")
    gender = RadioField('Gender:', choices = [('Male','Male'),('Female','Female')])
    address = TextAreaField("Address")
    town = TextField("Town:")
    telephone = TextField("Telephone:")
    cellphone = TextField("Cellphone:")
    insurance = SelectField('Insurance:', choices = [('IKA', 'IKA'),('TEVE', 'TEVE'),('Public Insurance', 'Public Insurance'),('Other', 'Other')])
#dimiourgia model gia tin sindesi me tin vasi dedomenon
class users(db.Model):
    id = db.Column('UID', db.Integer, primary_key = True)
    UserName = db.Column(db.String(30))
    UserPassword = db.Column(db.String(30))
    
    def __init__(self, UserName, UserPassword):
        self.UserName = UserName
        self.UserPassword = UserPassword
#dimiourgia model gia tin sindesi me tin vasi dedomenon
class doctors(db.Model):
    id = db.Column('DID', db.Integer, primary_key = True)
    DFName = db.Column(db.String(30))
    DLName = db.Column(db.String(30))
    DSpeciality = db.Column(db.String(40))
    DPhone = db.Column(db.String(10))
    
    def __init__(self, DFName, DLName, DSpeciality, DPhone):
        self.DFName = DFName
        self.DLName = DLName
        self.DSpeciality = DSpeciality
        self.DPhone = DPhone
#dimiourgia model gia tin sindesi me tin vasi dedomenon
class customers(db.Model):
    id = db.Column('CID', db.Integer, primary_key = True)
    CFName = db.Column(db.String(30))
    CLName = db.Column(db.String(30))
    CDate = db.Column(db.String(40))
    CSSN = db.Column(db.String(10))
    CGender = db.Column(db.String(40))
    CAddress = db.Column(db.String(40))
    CTown = db.Column(db.String(40))
    CTelephone = db.Column(db.String(10))
    CCellphone = db.Column(db.String(10))
    CInsurance = db.Column(db.String(40))
    
    def __init__(self, CFName, CLName, CDate, CSSN, CGender, CAddress, CTown, CTelephone, CCellphone, CInsurance):
        self.CFName = CFName
        self.CLName = CLName
        self.CDate = CDate
        self.CSSN = CSSN
        self.CGender = CGender
        self.CAddress = CAddress
        self.CTown = CTown
        self.CTelephone = CTelephone
        self.CCellphone = CCellphone
        self.CInsurance = CInsurance
#i appointment wtf form kai i sindesi tis me tin html
class AppointmentForm(Form):
    doctorslist=[]
    for i in range(1, doctors.query.count()):
        i=str(i)
        doctor = doctors.query.get(i)
        id = doctor.id
        name = doctor.DFName
        lastname = doctor.DLName
        speciality = doctor.DSpeciality
        info = str(name)+' '+str(lastname)+' '+str(speciality)
        doctorslist.append((id,info))
    
    customerslist=[]
    for i in range(1, customers.query.count()):
        i=str(i)
        customer = customers.query.get(i)
        id = customer.id
        name = customer.CFName
        lastname = customer.CLName
        ssn = customer.CSSN
        address = customer.CAddress
        telephone = customer.CTelephone
        info = str(name)+' '+str(lastname)+' '+str(ssn)+' '+str(address)+' '+str(telephone)
        customerslist.append((id,info))

    doctorlist = SelectField('Doctors:', choices = doctorslist)
    customerlist = SelectField('Customers:', choices = customerslist)
    appointmentdate = TextField("Appointment Date:")
    appointmenttime = TextField("Appointment Time:")
#dimiourgia model gia tin sindesi me tin vasi dedomenon
class appointments(db.Model):
    id = db.Column('AID', db.Integer, primary_key = True)
    DFName = db.Column(db.String(40))
    DLName = db.Column(db.String(40))
    CFName = db.Column(db.String(40))
    CLName = db.Column(db.String(40))
    ADate = db.Column(db.String(40))
    ATime = db.Column(db.String(40))
    
    def __init__(self,id,DFName, DLName, CFName, CLName, ADate, ATime):
        self.id = id
        self.DFName = DFName
        self.DLName = DLName
        self.CFName = CFName
        self.CLName = CLName
        self.ADate = ADate
        self.ATime = ATime

#class delAppointmentForm(Form):
#    delappointmentsList=[]
#    for i in range(1, appointments.query.count()):
#        f=str(i)
#        appointment = appointments.query.get(f)
#        id = appointment.id
#        dname = appointment.DFName
#        dlastname = appointment.DLName
#        cname = appointment.CFName
#        clastname = appointment.CLName
#        adate = appointment.ADate
#        atime = appointment.ATime
#        info = str(dname)+' '+str(dlastname)+' '+str(cname)+' '+str(clastname)+' '+str(adate)+' '+str(atime)
#        delappointmentsList.append((id,info))

#    delappointmentlist = SelectField('Appointments:', choices = delappointmentsList)

#dilosi tou url tis function kai tis methodous pou tha xrisimopoiisei
@userFlask.route('/new_customer', methods = ['GET', 'POST'])
def new_customer():
    form = CustomerForm()
#i energeia pou tha treksei otan patithei to koumpi submit
    if request.method == 'POST':
            customer = customers(form.name.data, form.lastname.data, form.dateofbirth.data, form.ssn.data, form.gender.data, form.address.data, form.town.data, form.telephone.data, form.cellphone.data, form.insurance.data)
            db.session.add(customer)
            db.session.commit()
            return redirect(url_for('main_menu'))
#i methodos pou ekteleite otan anoigei to html
    elif request.method == 'GET':
        return render_template('new_customer.html', form = form)

    return render_template('new_customer.html')

#dilosi tou url tis function kai tis methodous pou tha xrisimopoiisei
@userFlask.route('/new_appointment', methods = ['GET', 'POST'])
def new_appointment():
    form = AppointmentForm()
#i energeia pou tha treksei otan patithei to koumpi submit
    if request.method == 'POST':
        dname=''
        dlastname=''
        cname=''
        clastname=''
        for i in range(1, doctors.query.count()):
            i=str(i)
            doctor = doctors.query.get(i)
            if form.doctorlist.data == str(doctor.id):
                dname = str(doctor.DFName)
                dlastname = str(doctor.DLName)
    
        for i in range(1, customers.query.count()):
            i=str(i)
            customer = customers.query.get(i)
            if form.customerlist.data == str(customer.id):
                cname = str(customer.CFName)
                clastname = str(customer.CLName)
        
        appointment = appointments(dname, dlastname, cname, clastname, form.appointmentdate.data, form.appointmenttime.data)
        db.session.add(appointment)
        db.session.commit()
        return redirect(url_for('main_menu'))
#i methodos pou ekteleite otan anoigei to html
    elif request.method == 'GET':
        return render_template('new_appointment.html', form = form)
    
    return render_template('new_appointment.html')

#dilosi tou url tis function kai tis methodous pou tha xrisimopoiisei
@userFlask.route('/doctors', methods = ['GET', 'POST'])
def show_doctors():
#i energeia pou tha treksei otan patithei to koumpi submit
    if request.method == 'POST':
        return redirect(url_for('main_menu'))
    return render_template('show_doctors.html', doctors = doctors.query.all() )
#dilosi tou url tis function kai tis methodous pou tha xrisimopoiisei
@userFlask.route('/customers', methods = ['GET', 'POST'])
def show_customers():
#i energeia pou tha treksei otan patithei to koumpi submit
    if request.method == 'POST':
        return redirect(url_for('main_menu'))
    return render_template('show_customers.html', customers = customers.query.all() )
#dilosi tou url tis function kai tis methodous pou tha xrisimopoiisei
@userFlask.route('/appointments', methods = ['GET', 'POST'])
def show_appointments():
#i energeia pou tha treksei otan patithei to koumpi submit
    if request.method == 'POST':
        return redirect(url_for('main_menu'))
    return render_template('show_appointments.html', appointments = appointments.query.all() )
#dilosi tou url tis function kai tis methodous pou tha xrisimopoiisei
@userFlask.route('/delete_appointments', methods = ['GET', 'POST'])
def delete_appointments():
#i energeia pou tha treksei otan patithei to koumpi submit
    if request.method == 'POST':
        if request.form['submit']=='Back':
            return redirect(url_for('main_menu'))
        elif request.form['submit']=='Delete':
            daid = request.form['dappointmentid']
            sql = 'delete from appointments where AID='+daid
            while True:
                try:
                    db.engine.execute(sql)
                    break
                except exc.OperationalError:
                    return redirect(url_for('main_menu'))

    return render_template('delete_appointments.html', appointments = appointments.query.all() )

#@userFlask.route('/delete_appointment', methods = ['GET', 'POST'])
#def delete_appointment():
#    if request.method == 'POST':
#        form = delAppointmentForm()
#        dname=''
#        dlastname=''
#        cname=''
#        clastname=''
#        adate=''
#        atime=''
#        for i in range(1, appointments.query.count()):
#            i=str(i)
#            delappointment = appointments.query.get(i)
#            if form.delappointmentlist.data == str(delappointment.id):
#                dname = str(delappointment.DFName)
#                dlastname = str(delappointment.DLName)
#                cname = str(delappointment.CFName)
#                clastname = str(delappointment.CLName)
#                adate = str(delappointment.ADate)
#                atime = str(delappointment.ATime)
#                appointment = appointments(dname, dlastname, cname, clastname, adate, atime)
#                db.session.delete(appointment)
#                db.session.commit()
#    elif request.method == 'GET':
#        form = delAppointmentForm()
#        return render_template('delete_appointment.html', form = form)
#    return render_template('delete_appointment.html', form = form )

#dilosi tou url tis function kai tis methodous pou tha xrisimopoiisei
@userFlask.route('/', methods = ['GET', 'POST'])
def login():
#i energeia pou tha treksei otan patithei to koumpi submit
    if request.method == 'POST':
        if not request.form['username'] or not request.form['userpassword']:
            flash('Please enter all the fields', 'error')
        else:
            username = request.form['username']
            password = request.form['userpassword']
            sql = 'select * from users where UserName='+username+' and UserPassword='+password
            while True:
                try:
                    result = db.engine.execute(sql)
                    break
                except exc.OperationalError:
                    return redirect(url_for('login'))
            if result != '':
                return redirect(url_for('main_menu'))
            else:
                flash('Wrong username or password', 'error')
    return render_template('login.html', users = users.query.all() )
#dilosi tou url tis function kai tis methodous pou tha xrisimopoiisei
@userFlask.route('/main_menu', methods = ['GET', 'POST'])
def main_menu():
#i energeia pou tha treksei otan patithei to koumpi submit
    if request.method == 'POST':
        if request.form['submit']=='Doctors List':
            return redirect(url_for('show_doctors'))
        elif request.form['submit']=='Customers List':
            return redirect(url_for('show_customers'))
        elif request.form['submit']=='Appointments List':
            return redirect(url_for('show_appointments'))
        elif request.form['submit']=='Add Customer':
            return redirect(url_for('new_customer'))
        elif request.form['submit']=='Create Appointment':
            return redirect(url_for('new_appointment'))
        elif request.form['submit']=='Delete Appointment':
            return redirect(url_for('delete_appointments'))
    return render_template('main_menu.html')

if __name__ == '__main__':
    db.create_all()
    userFlask.run(debug = True)
